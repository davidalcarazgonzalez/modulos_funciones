def suma_numeros():
    numeros = []

    while True:
        try:
            entrada = input("Introduce un número (o 'q' para terminar): ")

            if entrada.lower() == 'q':
                break

            numero = float(entrada)
            numeros.append(numero)
        except ValueError:
            print("Error: Introduce un número válido.")

    resultado = sum(numeros)
    return resultado


if __name__ == "__main__":
    try:
        resultado_final = suma_numeros()
        print(f"La suma de los números introducidos es: {resultado_final}")
    except Exception as e:
        print(f"Error inesperado: {e}")
