#dos funciones que están en el módulo ejemplo2
#un módulo que puede contener class, variables y funciones
class Producto:
    def __int__(self,nombre,unidades):
        self.nombre=nombre
        self.unidades=unidades

alummnos={} #dict
asignaturas={} #lista
calificaciones={} #tupla

def calcular_cuadrado():
    print("calcular cuadrado")
def calcular_cubo():
    print("calcular cubo")

