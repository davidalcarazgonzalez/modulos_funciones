def obtener_numeros_pares(inicial, final):
    if not isinstance(inicial, int) or not isinstance(final, int):
        raise ValueError("Ambos números deben ser enteros.")

    if inicial > final:
        raise ValueError("El número inicial debe ser menor o igual al número final.")

    numeros_pares = [num for num in range(inicial, final + 1) if num % 2 == 0]
    return numeros_pares


if __name__ == "__main__":
    try:
        numero_inicial = int(input("Introduce el número inicial: "))
        numero_final = int(input("Introduce el número final: "))

        numeros_pares = obtener_numeros_pares(numero_inicial, numero_final)

        if numeros_pares:
            print(f"Números pares entre {numero_inicial} y {numero_final}: {numeros_pares}")
        else:
            print(f"No hay números pares en el rango.")

    except ValueError as ve:
        print(f"Error: {ve}")
    except Exception as e:
        print(f"Error inesperado: {e}")
