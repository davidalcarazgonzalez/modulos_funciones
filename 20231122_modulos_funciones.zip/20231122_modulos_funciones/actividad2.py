from datetime import datetime


def calcular_descuento(subtotal, fecha):
    dia_del_mes = fecha.day
    if dia_del_mes < 15:
        descuento = subtotal * 0.05
        subtotal -= descuento
    return subtotal


def calcular_total(unidades, precio):
    subtotal = unidades * precio
    return subtotal


def obtener_fecha_actual():
    return datetime.now()


if __name__ == "__main__":
    try:
        unidades = int(input("Introduce la cantidad de unidades: "))
        precio = float(input("Introduce el precio unitario: "))

        total = calcular_total(unidades, precio)
        fecha_actual = obtener_fecha_actual()
        total_con_descuento = calcular_descuento(total, fecha_actual)

        print(f"Subtotal: ${total:.2f}")
        print(f"Fecha actual: {fecha_actual.strftime('%Y-%m-%d')}")

        if total != total_con_descuento:
            print(f"Se aplica un descuento del 5%.")
            print(f"Total con descuento: ${total_con_descuento:.2f}")
        else:
            print("No se aplica el descuento.")

    except ValueError:
        print("Error: Introduce datos válidos.")
    except Exception as e:
        print(f"Error: {e}")
